﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PlaneRez.Models
{
    public class Flight
    {
        public Location Location { get; set; }
        public string Time { get; set; }
        public Plane AircraftInfo { get; set; }
        public Plane PlaneInfo { get; set; }
        public Location DepartureLocation { get; set; }
        public Location ArrivalLocation { get; set; }
    }
}
