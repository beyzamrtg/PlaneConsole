﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PlaneRez.Models
{
   public class Reservation
    {
        public Flight Flight { get; set; }
        public Customer Customer { get; set; }
    }
}
