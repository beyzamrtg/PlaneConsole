﻿using PlaneRez.Models;
using PlaneRez.Services;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;

namespace PlaneRez
{

    class Program
    {
        static void Main()
        {
            Program program = new Program();
            program.Run();
        }

        private List<Plane> planes = new List<Plane>();
        private List<Location> locations = new List<Location>();
        private List<Flight> flights = new List<Flight>();
        private List<Reservation> reservations = new List<Reservation>();

        public void Run()
        {
            bool continueExecution = true;

            while (continueExecution)
            {
                Console.WriteLine("1. Add Plane");
                Console.WriteLine("2. Add Location");
                Console.WriteLine("3. Add Flight");
                Console.WriteLine("4. Make Reservation");
                Console.WriteLine("5. Exit");

                Console.Write("Please enter an option: ");
                string choice = Console.ReadLine();

                switch (choice)
                {
                    case "1":
                        AddPlane();
                        break;
                    case "2":
                        AddLocation();
                        break;
                    case "3":
                        AddFlight();
                        break;
                    case "4":
                        MakeReservation();
                        break;
                    case "5":
                        continueExecution = false;
                        break;
                    default:
                        Console.WriteLine("Invalid option, please try again.");
                        break;
                }
            }
        }

        private void AddPlane()
        {
            Console.ForegroundColor = ConsoleColor.Blue;
            Console.WriteLine("Adding Plane Process");
            Console.Write("Model: ");
            string model = Console.ReadLine();
            Console.Write("Brand: ");
            string brand = Console.ReadLine();
            Console.Write("Serial Number: ");
            string serialNumber = Console.ReadLine();
            Console.Write("Seating Capacity: ");
            int seatingCapacity;
            if (int.TryParse(Console.ReadLine(), out seatingCapacity))
            {
                Plane plane = new Plane { Model = model, Brand = brand, SerialNumber = serialNumber, SeatingCapacity = seatingCapacity };
                planes.Add(plane);
                Console.WriteLine("Plane added successfully.");
            }
            else
            {
                Console.WriteLine("Invalid seating capacity. Process canceled.");
            }
            Console.ResetColor();
            FileService.SaveDataToJson(planes, "planes");
        }

        private void AddLocation()
        {
            Console.ForegroundColor = ConsoleColor.Magenta;
            Console.WriteLine("Adding Location Process");
            Console.Write("Country: ");
            string country = Console.ReadLine();
            Console.Write("City: ");
            string city = Console.ReadLine();
            Console.Write("Airport: ");
            string airport = Console.ReadLine();
            Console.Write("Active (true/false): ");
            bool active;
            if (bool.TryParse(Console.ReadLine(), out active))
            {
                Location location = new Location { Country = country, City = city, Airport = airport, Active = active };
                locations.Add(location);
                Console.WriteLine("Location added successfully.");
            }
            else
            {
                Console.WriteLine("Invalid active value. Process canceled.");
            }
            Console.ResetColor();
            FileService.SaveDataToJson(locations, "locations");
        }

        private void AddFlight()
        {
            Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine("Adding Flight Process");
            Console.WriteLine("Enter locations in the following format (Country,City,Airport,Active):");
            Console.Write("Departure Location: ");
            Location departureLocation = EnterLocation();
            Console.Write("Arrival Location: ");
            Location arrivalLocation = EnterLocation();
            Console.Write("Time: ");
            string time = Console.ReadLine();
            Console.Write("Plane Model: ");
            string planeModel = Console.ReadLine();

            Plane plane = planes.Find(p => p.Model == planeModel);
            if (plane != null)
            {
                Flight flight = new Flight { DepartureLocation = departureLocation, ArrivalLocation = arrivalLocation, Time = time, PlaneInfo = plane };
                flights.Add(flight);
                Console.WriteLine("Flight added successfully.");
            }
            else
            {
                Console.WriteLine($"Plane not found. Please add the '{planeModel}' model plane.");
            }
            Console.ResetColor();
            FileService.SaveDataToJson(flights, "flights");
        }

        private void MakeReservation()
        {
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine("Reservation Process");
            Console.Write("First Name: ");
            string firstName = Console.ReadLine();
            Console.Write("Last Name: ");
            string lastName = Console.ReadLine();
            Console.Write("Age: ");
            int age;
            if (int.TryParse(Console.ReadLine(), out age))
            {
                Console.Write("Flight Time: ");
                string flightTime = Console.ReadLine();

                Flight flight = flights.Find(f => f.Time == flightTime);
                if (flight != null)
                {
                    Customer customer = new Customer { FirstName = firstName, LastName = lastName, Age = age };
                    Reservation reservation = new Reservation { Flight = flight, Customer = customer };

                    if (flight.PlaneInfo.SeatingCapacity > 0)
                    {
                        reservations.Add(reservation);
                        flight.PlaneInfo.SeatingCapacity -= 1;
                        Console.WriteLine("Reservation completed successfully.");
                    }
                    else
                    {
                        Console.WriteLine("Sorry, the plane is full. Reservation couldn't be made.");
                    }
                }
                else
                {
                    Console.WriteLine($"Flight not found. Please add the flight scheduled at '{flightTime}'.");
                }
            }
            else
            {
                Console.WriteLine("Invalid age value. Process canceled.");
            }
            Console.ResetColor();
            FileService.SaveDataToJson(reservations, "reservations");
        }

        private Location EnterLocation()
        {
            string[] locationInfo = Console.ReadLine().Split(',');
            if (locationInfo.Length == 4)
            {
                string country = locationInfo[0];
                string city = locationInfo[1];
                string airport = locationInfo[2];
                bool active;
                if (bool.TryParse(locationInfo[3], out active))
                {
                    return new Location { Country = country, City = city, Airport = airport, Active = active };
                }
            }

            Console.WriteLine("Invalid location format. Process canceled.");
            return null;
        }
    }

}